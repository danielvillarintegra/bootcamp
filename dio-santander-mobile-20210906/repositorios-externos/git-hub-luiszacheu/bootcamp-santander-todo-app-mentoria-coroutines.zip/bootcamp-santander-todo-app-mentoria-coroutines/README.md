# bootcamp-santander-todo-app
App de exemplo para o Bootcamp Santander Trilha Mobile Kotlin

## branches:

**init**: projeto base para a mentoria

**addretrofit/final**: projeto final integrado com o retrofit
