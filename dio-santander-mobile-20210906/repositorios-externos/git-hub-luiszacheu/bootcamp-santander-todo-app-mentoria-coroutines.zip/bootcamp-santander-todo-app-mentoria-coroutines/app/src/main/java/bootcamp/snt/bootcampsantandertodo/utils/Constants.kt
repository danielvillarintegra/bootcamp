package bootcamp.snt.bootcampsantandertodo.utils

object Constants {

    const val KEY_EXTRA_TODO_INDEX = "KEY_EXTRA_TODO_INDEX"

    const val KEY_EXTRA_TODO_ID = "KEY_EXTRA_TODO_ID"

    const val CODE_RESULT_CREATE_SUCCESS = 1

    const val CODE_RESULT_REMOVE_SUCCESS = 2
}