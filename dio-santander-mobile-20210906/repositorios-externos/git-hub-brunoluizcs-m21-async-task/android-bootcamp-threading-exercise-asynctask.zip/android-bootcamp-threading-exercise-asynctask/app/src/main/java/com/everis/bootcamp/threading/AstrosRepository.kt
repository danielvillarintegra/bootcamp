package com.everis.bootcamp.threading


//TODO: 010 - Criar a classe responsável por carregar os dados
class AstrosRepository {

    //TODO: 011 - Criar função para carregar os astronautas

    //TODO: 012 - Criar função para converter o json
}