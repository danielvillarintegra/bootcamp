package com.everis.bootcamp.threading


//TODO: 009 Criar classe para representar o resultado da api
