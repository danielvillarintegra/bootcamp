package com.everis.bootcamp.threading


//TODO: 007 - Criar classe para representar o astronauta
