# Understanding the Android Threading Model

Exercício prático sobre os modelos de Threads no Android exemplificado com a implementação de AsyncTask

