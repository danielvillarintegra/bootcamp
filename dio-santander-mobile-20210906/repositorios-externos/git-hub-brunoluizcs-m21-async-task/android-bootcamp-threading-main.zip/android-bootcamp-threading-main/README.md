# Understanding the Android Threading Model

Exercício prático sobre os modelos de Threads no Android exemplificado com a implementação de AsyncTask

## Orientações 

Realize o clone do projeto e faça a mudança para a branch *exercise-asynctask*, nesta branch existem alguns TODO's que você deve seguir para completar o exercício,
se tiver com dúvidas ou encontrar dificuldades a branch *exercise-asynctask-completed* contém o código completo com todos os TODO's resolvidos.

