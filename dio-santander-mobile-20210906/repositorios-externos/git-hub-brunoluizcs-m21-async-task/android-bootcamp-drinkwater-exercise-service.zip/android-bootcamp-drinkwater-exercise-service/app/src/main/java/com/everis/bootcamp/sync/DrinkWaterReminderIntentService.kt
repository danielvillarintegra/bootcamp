package com.everis.bootcamp.sync


//TODO: 004 - Extenda a classe IntentService e no construtor passe o parâmetro com o mesmo nome desta classe
class DrinkWaterReminderIntentService {

    /*TODO: 005 - Sobrescreva o metodo onHandleIntent
        - Pegue a ação da intent que startou este service
        - Chame o método DrinkWaterReminderTask.executeTask e passe a action no parâmetro
     */

}