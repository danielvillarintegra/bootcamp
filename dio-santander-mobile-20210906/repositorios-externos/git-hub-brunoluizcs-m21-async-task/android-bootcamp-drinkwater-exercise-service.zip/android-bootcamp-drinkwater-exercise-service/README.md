# Performing Background Work with Services

Exercício prático sobre implementação de services, realize o clone do projeto e faça checkout para a branch exercise-service, a branch exercise-service-completed possui o exercício resolvido para consulta.

