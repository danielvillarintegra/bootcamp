package com.br.natanfc.filmesflix.view

import android.view.View
import androidx.recyclerview.widget.RecyclerView

class MoviesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)