package br.com.dio.app.repositories.core

class RemoteException(override val message: String) : Throwable()